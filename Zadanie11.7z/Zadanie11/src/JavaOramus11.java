public class JavaOramus11 {

    public static void main(String[] args) {
        
        
        
    }
    
}
