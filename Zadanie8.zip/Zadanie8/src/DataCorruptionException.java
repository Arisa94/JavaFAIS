
public class DataCorruptionException extends Exception{
    
    private static final long serialVersionUID = 3394812597654772576L;
    
}
