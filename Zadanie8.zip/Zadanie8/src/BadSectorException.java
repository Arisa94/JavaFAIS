
public class BadSectorException extends Exception {

    private static final long serialVersionUID = -4252467929543180544L;

}
